
/*   audio  */

$(document).ready(function(){
var aud = $('#audio-src')[0];
aud.ontimeupdate = function(){
document.getElementById('durttl').innerHTML = minAndSec(aud.duration);
$('.progress').css('width', aud.currentTime / aud.duration * 100 + '%');
 document.getElementById('elapse').innerHTML = minAndSec(aud.currentTime);
};});

 function minAndSec(sec) {
 if(isNaN(sec)){
 return '';
 }else{
 sec = parseInt(sec);
 hrs = Math.floor(sec / 3600);
 sec %= 3600;
 sec = Math.floor( sec );
 min = Math.floor( sec / 60 );
 min = min >= 10 ? min : '0' + min;
 sec = Math.floor( sec % 60 );
 sec = sec >= 10 ? sec : '0' + sec;
 return hrs + ':' + min + ':'+ sec;
 } }

$(document).on('swipeleft', '#audio-player', function(){
$('#audio-player').removeClass('slide-in');
$('#audio-player').addClass('slide-out');
$('#audio-src')[0].pause();
});

/*
 tap handler for tooltip on page4, by class .page4
*/
$(document).on('tap', '.page4', function(){
$('#tooltip').addClass('tooltip-off');
});

$(document).on('tap', '.about_button', function(){
$('#about').removeClass('unhide');
});



  /* slider on page4 */
   $(document).on('change','#slider',function(event){
      var e=$(this).closest('[id]').attr('id');
      var value=this.value;
      document.getElementById('font-span').innerHTML = value+'px';
      RFO(e+':'+value);
   });

$(document).on('pagebeforeshow',function(){
  $('#slider').next().find('.ui-slider-handle').css({'width':'8px', 'border':'#3092c0','background': 'linear-gradient(to bottom, #333, #999, #333)','margin':'-13px 0 0 -8px'});
  $('#slider').next('.ui-slider-track').css({'margin':'0 0 0 54px','height':'10px','border':'1px', 'background':'#999'});
   $('#slider').next().find('.ui-btn-active').css({background:'linear-gradient(to right, #111, #eee, #111)'});
});

 /* bar-z test (in menu) */
function clearbar(num) { setTimeout(function(){ document.getElementById('bar-top-left').innerHTML=' '; document.getElementById('bar-left').innerHTML=' '; document.getElementById('bar-right').innerHTML=' '; }, num); }

 /* check if online  */
function offlineindicator() { online = window.navigator.onLine; if (navigator.onLine) { RFO('online'); } else { RFO('offline'); } }

/* gets the screen size for pictures and video */

function getwidth() { var w = screen.width; RFO(w); }
function getheight() { var h = screen.height; RFO(h);}

 /* listview1 check all checkbox */
$(document).on('change','#selectallfolders',function(e){ if( $(this).is(':checked') ) { RFO('allfchecked:');
  $('input.chkfolder').prop('checked',true); }else{ 
    RFO('allfunchecked:'); 
  $('input.chkfolder').prop('checked',false); }});

  /* listview1 item checkbox */ 
$(document).on('change','.chkfolder',function(event){
   if( $(this).is(':checked') ) { 
    RFO('fochecked:'+event.target.id); }else{ 
    RFO('founchecked:'+event.target.id); }
  });
  
    /*  listview2 check all files*/
$(document).on('change','#selectallfiles',function(e){
 if( $(this).is(':checked') ) { RFO('allchecked:'); 
 $('input.chkfile').prop('checked',true); }else{ 
   RFO('allunchecked:'); 
  $('input.chkfile').prop('checked',false); }
});

 /*  listview2 item checkbox */
$(document).on('change' , '.chkfile', function(event){
  if( $(this).is(':checked') ) {
  RFO('fichecked:'+event.target.id); }else{ 
  RFO('unfichecked:'+event.target.id); } 
});


/* editor   */
 /* font-size selectbox */
$(document).on('change', 
 '#select-font', function(event){
  var e=$(this).closest('[id]').attr('id');
  var val = $(this).find(':SELECTed').text();
  RFO(e+':'+val);
 })

 /* on focus function to Adjust the popup size */
 $(document).on('focus', 
 '#editor', function(){
  var h = screen.height;
 $('#editor-popup').css('height', h-400+'px');
 RFO('EDITED');})
 
 /* on focusout need to readjust the popup size */
 $(document).on('focusout', 
 '#editor', function(){
  var h = screen.height;
 $('#editor-popup').css('height', h-100+'px');
 })
 
 /* count the characters in a document AFTER doc is loaded  */
  function initcount(num) { setTimeout(function()
  { var text_len = $('#editor').val().length;
  $('#editor-count').text(' '+text_len);
 }, num);}
 
 /* function to count characters live */
 $(document).on('keyup', 
 '#editor', function(){ 
 var text_len = $('#editor').val().length;
  $('#editor-count').text(' '+text_len);
 })
 
 /* script for path-box on main page */
  $(document).on('change','#path-box',function(event){
  var e=$(this).closest('[id]').attr('id');
  var value=this.value;
  RFO(e+':'+value);
  });
 
 /* close video */
$(document).on('swiperight','#viewvideo', function(event) {
 $('#viewvideo-video')[0].pause();
 $('#viewvideo').popup('close');
 });
 
 /* close picture */
$(document).on('swiperight', 
 '#showpicture', function(){
 $('#showpicture').popup('close');
  RFO('imageclosed');
 });
 
 
 /* some zip stuff */
 /* close zip popup */
$(document).on('swiperight popupafterclose',
 '#zip_popup', function(){
 $('#zip_popup').popup('close');
  RFO('ZIP_POPUP_CLOSED');
 });
 
 /* on change listener for all checkboxes in zip_popup  
    this listener is BY CLASS not id
    a lot like the main page listviews 
    .zipfile is in ctl  LV4$()
 */
 
$(document).on('change','.zipfile',function(event){  
  if( $(this).is(':checked') ) { RFO('zipchecked:'+event.target.id); }else{ RFO('zipunchecked:'+event.target.id);}
 });
 
 /* close copy popup */
$(document).on('swiperight popupafterclose',
 '#copy-input', function(){
 $('#copy-input').popup('close');
  RFO('COPY_INPUT_CLOSED');
 });
 
 /*  close search popup  */
$(document).on('swiperight popupafterclose',
 '#search', function(){
 $('#search').popup('close');
  RFO('POPUP_CLOSED');
 });
 
$(document).on('swiperight popupafterclose',
 '#custom_popup', function(){
 $('#custom_popup').popup('close');
  RFO('CUSTOM_CLOSED');
 });
 
 
$(document).on('swiperight popupafterclose',
 '#lv_input', function(){
 $('#lv_input').popup('close');
  RFO('CLOSED');
 });
 
 
 