


/*   audio  */

$(document).ready(function(){
var aud = $('#audio-src')[0];
aud.ontimeupdate = function(){
document.getElementById('durttl').innerHTML = minAndSec(aud.duration);
$('.progress').css('width', aud.currentTime / aud.duration * 100 + '%');
 document.getElementById('elapse').innerHTML = minAndSec(aud.currentTime);
};
});

 function minAndSec(sec) {
 if(isNaN(sec)){
 return '';
 }else{
 sec = parseInt(sec);
 hrs = Math.floor(sec / 3600);
 sec %= 3600;
 sec = Math.floor( sec );
 min = Math.floor( sec / 60 );
 min = min >= 10 ? min : '0' + min;
 sec = Math.floor( sec % 60 );
 sec = sec >= 10 ? sec : '0' + sec;
 return hrs + ':' + min + ':'+ sec;
 } };

$(document).on('swipeleft', '#audio-player', function(){
$('#audio-player').removeClass('slide-in');
$('#audio-player').addClass('slide-out');
$('#audio-src')[0].pause();
});

/*
 tap handler for tooltip on page4, by class .page4
*/
$(document).on('tap', '.page4', function(){
$('#tooltip').addClass('tooltip-off');
});

$(document).on('tap', '#aboutb', function(){
$('#about').removeClass('unhide');
});



 /* bar-z test (in menu) */
function clearbar(num) { setTimeout(function(){ document.getElementById('bar-top-left').innerHTML=' '; document.getElementById('bar-left').innerHTML=' '; document.getElementById('bar-right').innerHTML=' '; }, num); };



 /* check if online  */
function offlineindicator() { online = window.navigator.onLine; if (navigator.onLine) { RFO('online'); } else { RFO('offline'); }; }; 


/* gets the screen size for pictures and video */

function getwidth() { var w = screen.width; RFO(w); };
function getheight() { var h = screen.height; RFO(h);};


 /* listview1 check all checkbox */
$(document).on('change','#selectallfolders',function(e){ if( $(this).is(':checked') ) { RFO('allfchecked:');
  $('input.chkfolder').prop('checked',true); }else{ 
    RFO('allfunchecked:'); 
  $('input.chkfolder').prop('checked',false); }});

  /* listview1 item checkbox */ 
$(document).on('change','.chkfolder',function(event){
   if( $(this).is(':checked') ) { 
    RFO('fochecked:'+event.target.id); }else{ 
    RFO('founchecked:'+event.target.id); }
  });
  
    /*  listview2 check all files*/
$(document).on('change','#selectallfiles',function(e){
 if( $(this).is(':checked') ) { RFO('allchecked:'); 
 $('input.chkfile').prop('checked',true); }else{ 
   RFO('allunchecked:'); 
  $('input.chkfile').prop('checked',false); }
});

 /*  listview2 item checkbox */
$(document).on('change' , '.chkfile', function(event){
  if( $(this).is(':checked') ) {
  RFO('fichecked:'+event.target.id); }else{ 
  RFO('unfichecked:'+event.target.id); } 
});
 
 


